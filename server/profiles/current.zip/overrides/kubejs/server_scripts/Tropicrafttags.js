onEvent('tags.items', event => {
	event.add('tropicraft:logs', 'tropicraft:papaya_log'),
	event.add('minecraft:planks', '#tropicraft:planks'),
	event.add('minecraft:logs', '#tropicraft:logs')
})