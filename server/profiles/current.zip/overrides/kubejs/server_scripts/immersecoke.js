onEvent('recipes', event => {
	// Change recipes here
event.recipes.immersiveengineeringCokeOven('1x mekanism:dust_charcoal', '#forge:dusts/wood').creosote(125).time(400)
})
