onEvent('recipes', event => {
	// Change recipes here
	event.recipes.mekanismCrushing('2x mekanism:bio_fuel', '#minecraft:leaves'),
	event.recipes.mekanismCrushing('2x mekanism:bio_fuel', '#minecraft:saplings'),
	event.recipes.mekanismCrushing('2x mekanism:bio_fuel', '#forge:seeds')
	 
})
