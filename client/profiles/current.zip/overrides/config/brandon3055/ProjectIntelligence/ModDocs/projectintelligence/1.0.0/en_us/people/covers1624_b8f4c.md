§align:center
##### §ncovers1624§n
§rule{height:20}
§entity[player:covers1624]{size:128,track_mouse:true}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
covers1624 is the creator creator of... umm... nothing? Yet he single-handedly ported a large number of the well known mods to Minecraft 1.12.
He is the current maintainer of all Chicken Bones mods, a member of TeamCoFH, and has contributed to more mods than I can count!

Covers has also helped a lot with the server-side back end for Project Intelligence.
§rule{colour:0x606060,height:3,width:100%,top_pad:0}