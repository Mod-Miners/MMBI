§align:center
##### §nModule System§n
§4[WIP I still need to document the differnt modules]§4
Ok so here's the deal. There have been a few changes around here since the days of 1.12. First of all, you may have noticed the tool and armor recipes are a bit cheaper than they were last you checked. Well, that's because those items are now basically useless... But that's ok! we can fix that! 

Ok, so I may have exaggerated a little. The draconic pickaxe for example still works as a pickaxe, but that's all it does. It has no other fancy functions and it's only a little faster than a diamond pickaxe. And it's a similar story for all the tools. 
§rule{colour:0x606060,height:2,width:100%}
Once you have your first modular item you can access its module configuration by pressing SHIFT+C while holding the item.§o If this does not work you may need to check your keybindings§o

You should now see a module screen that looks something like this:
§img[https://ss.brandon3055.com/f8796]{width:80%} 

The grid you see can be populated with upgrade modules.
Modules can come in different shapes and sizes so some modules will take up multiple slots in the grid.

Some modules are also available in different tiers. A module's tier must be equal to or lower than the tier of the item it is being installed in. 

Certain modules are "universal" for example energy storage or speed. But some modules can only be installed in certain items.

It's worth noting that by default modular tools have no energy storage capacity so you will probably want to start by installing an energy storage module.

For more information on specific modules see the modules page §4[Not yet documented]§4
§rule{colour:0x606060,height:2,width:100%}