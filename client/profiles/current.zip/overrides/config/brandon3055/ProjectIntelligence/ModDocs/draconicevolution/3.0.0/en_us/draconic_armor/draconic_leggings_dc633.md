§align:center
##### §nDraconic Leggings§n

§stack[draconicevolution:draconic_legs]{size:64}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§bStats

Speed Boost (Configurable)
+180 Base Shield Capacity
+3 Armor Toughness
+6 Armor

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicevolution:draconic_legs]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}