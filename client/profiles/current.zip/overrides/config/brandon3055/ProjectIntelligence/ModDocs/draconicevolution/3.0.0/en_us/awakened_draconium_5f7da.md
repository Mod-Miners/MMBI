§align:center
##### §nAwakened Draconium§n

§stack[draconicevolution:awakened_draconium_nugget]{size:32} §stack[draconicevolution:awakened_draconium_ingot]{size:32} §stack[draconicevolution:awakened_draconium_block]{size:32}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
Awakened Draconium is your next step towards crafting even more powerful tools, weapons and armor!

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicevolution:awakened_draconium_ingot]{spacing:2}§recipe[draconicevolution:awakened_draconium_block]{spacing:2}§recipe[draconicevolution:awakened_draconium_nugget]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:0}