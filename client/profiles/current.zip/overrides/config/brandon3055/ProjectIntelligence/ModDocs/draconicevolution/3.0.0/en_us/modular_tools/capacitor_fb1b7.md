§align:center
##### §nCapacitors§n

§stack[draconicevolution:wyvern_capacitor]{size:64}§stack[draconicevolution:draconic_capacitor]{size:64}§stack[draconicevolution:chaotic_capacitor]{size:64}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicevolution:wyvern_capacitor]{spacing:2}
§recipe[draconicevolution:draconic_capacitor]{spacing:2}
§recipe[draconicevolution:chaotic_capacitor]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}