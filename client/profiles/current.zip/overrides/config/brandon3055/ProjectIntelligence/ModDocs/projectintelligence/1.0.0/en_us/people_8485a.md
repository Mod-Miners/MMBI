§align:center
##### §nWe are the people!§n

§rule{colour:0x606060,height:3,width:100%}
People referenced in PI documentation live here.
This can include anyone directly related to mod(s) they are referenced in. This includes mod developers, artists, etc.
§rule{colour:0x606060,height:3,width:100%}
