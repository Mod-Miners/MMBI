§align:center
##### §nItem Dislocator§n

§stack[draconicevolution:magnet]{size:64}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
Using the teleportation power of a dislocator you have found a way to teleport items dropped in the world directly into your inventory!
The range of this dislocator is 8 blocks.

To activate, simply shift+right click.

§6Quality Of Life features§r
Holding shift will temporarily disable the dislocator.
If another player is within 3 blocks of an item and they are closer to it than you are the dislocator will not collect it.
When you throw an item the dislocator will wait for its pick up delay to expire before collecting it again. (Meaning you can actually throw items to other players now!)


§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicevolution:magnet]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}