§align:center
##### §nDraconic Helmet§n

§stack[draconicevolution:draconic_helm]{size:64}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§bStats

Night Vision (Configurable)
Cures negative potion effects
Bypass suffocation and drowning damage
Removes mining slowdown underwater (Aqua Affinity)
+60 Base Shield Capacity
+3 Armor Toughness
+3 Armor

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicevolution:draconic_helm]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}