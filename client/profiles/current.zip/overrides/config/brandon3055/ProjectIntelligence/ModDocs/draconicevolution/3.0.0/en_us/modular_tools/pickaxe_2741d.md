§align:center
##### §nPickaxes§n
§stack[draconicevolution:wyvern_pickaxe]{size:64}§stack[draconicevolution:draconic_pickaxe]{size:64}§stack[draconicevolution:chaotic_pickaxe]{size:64}
§rule{colour:0x606060,height:3,width:100%,top_pad:0}
In their default configuration these tools are just a little more effective than diamond tools. Install upgrade moduals to enhance their functionality.
§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicevolution:wyvern_pickaxe]{spacing:2}
§recipe[draconicevolution:draconic_pickaxe]{spacing:2}
§recipe[draconicevolution:chaotic_pickaxe]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}

§entity[player:brandon3055]{size:80,rotate_speed:1.0,main_hand:"draconicevolution:wyvern_pickaxe"}§entity[player:brandon3055]{size:80,rotate_speed:1.0,main_hand:"draconicevolution:draconic_pickaxe"}§entity[player:brandon3055]{size:80,rotate_speed:1.0,main_hand:"draconicevolution:chaotic_pickaxe"}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}