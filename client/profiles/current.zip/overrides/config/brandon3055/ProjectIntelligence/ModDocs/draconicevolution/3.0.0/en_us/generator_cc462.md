§align:center
##### §nGenerator§n

§stack[draconicevolution:generator]{size:64}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
Introducing the new and improved draconic generator! Now you can choose whether you want to maximize efficiency to stretch out your fuel reserves, Absolutely wreck your fuel reserves but maximize energy output! Or maybe just settle somewhere in between. 

###### §nOperating Modes§n
§table{border_colour:0x606060,width:100%,padding:2,colour:0x0}
| §7Mode | §7Power Output | §7Fuel Efficiency |
| :---- | :---- | :---- |
| §7Eco Plus 		| §75 OP/t 		| §7500%	|
| §7Eco 			| §720 OP/t 	| §7150%	|
| §7Normal 		| §740 OP/t 	| §7100%	|
| §7Performance	| §780 OP/t 	| §780% 	|
| §7Overdrive 		| §7300 OP/t	| §750% 	|

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicevolution:generator]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}
