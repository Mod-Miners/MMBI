§align:center
##### §nStaffs of power§n
§stack[draconicevolution:draconic_staff]{size:64}§stack[draconicevolution:chaotic_staff]{size:64}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicevolution:draconic_staff]{spacing:2}
§recipe[draconicevolution:chaotic_staff]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}

§entity[player:brandon3055]{size:100,rotate_speed:1.0,main_hand:"draconicevolution:draconic_staff"}§entity[player:brandon3055]{size:100,rotate_speed:1.0,main_hand:"draconicevolution:chaotic_staff"}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}