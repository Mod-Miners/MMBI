§align:center
##### §n欢迎来到PI§n

§rule{colour:0x606060,height:3,width:100%,top_pad:0}

这个开源项目是由 §link[projectintelligence:people/brandon3055]{alt_text:"brandon3055"} 制作的。该项目的目标是通过利用Minecraft社区的力量创建一个真正的通用文档。

那么这将如何运作？ 对于初学者来说，任何mod开发人员都可以为他们的mod添加文档。 问题是mod开发人员很忙，所以大部分人都没有时间编写文档，而且在我看来，这是大多数当前文档模块的主要问题。 PI旨在通过使用相对简单的内置编辑器编写各种mod的文档，使社区中的任何人都能够做出贡献来解决这个问题。 然后，他们可以通过PI提交文档，如果通过审核，则会将其添加到在线存储库中。

PI所做的一切都是开源的。 所有文档都以原始形式存储在github上。 然后由jenkins服务器构建并上传到由§link[projectintelligence:people/covers1624]{alt_text:"covers1624"} 控制的Web服务器，PI可以访问它。 PI使用的所有内容都来自此服务器，包括文档中使用的所有图像。 不向外面的服务器发出请求。

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§align:left
§c//这个文档正在编写。 讽刺的是......我花了很多时间编写一个文档mod，我没有时间写文档...