§align:center
##### §nDraconic Shovel§n

§stack[draconicevolution:draconic_shovel]{size:128}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§b§nStats

§616 Million RF capacity upgradable to 256 Million.

§63x3 base mining AOE. Upgradable to 9x9

§63 block dig depth. Upgradable to 9

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicevolution:draconic_shovel]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}