§align:center
##### §nPickaxes§n

§stack[draconicevolution:wyvern_bow]{size:64}§stack[draconicevolution:draconic_bow]{size:64}§stack[draconicevolution:chaotic_bow]{size:64}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
In their default configuration these tools are just a little more effective than diamond tools. Install upgrade moduals to enhance their functionality.
§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicevolution:wyvern_bow]{spacing:2}
§recipe[draconicevolution:draconic_bow]{spacing:2}
§recipe[draconicevolution:chaotic_bow]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}

§entity[player:brandon3055]{size:80,rotate_speed:1.0,main_hand:"draconicevolution:wyvern_bow"}§entity[player:brandon3055]{size:80,rotate_speed:1.0,main_hand:"draconicevolution:draconic_bow"}§entity[player:brandon3055]{size:80,rotate_speed:1.0,main_hand:"draconicevolution:chaotic_bow"}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}