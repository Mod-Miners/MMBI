§align:center
##### §nDraconic Hoe§n

§stack[draconicevolution:draconic_hoe]{size:128}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§b§nStats

§616 Million RF capacity upgradable to 256 Million.

§63x3 base mining AOE. Upgradable to 9x9

§6Land Fill Mode
When this mode is enabled it will try to automatically level out the terrain as it tills using dirt from your inventory.
It will fill up to a 1 block deep depression and harvest up to 1 block above the tilling area.
Any blocks harvested are placed in the player's inventory.

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicevolution:draconic_hoe]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}